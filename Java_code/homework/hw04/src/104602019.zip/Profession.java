
public interface Profession {
	public String skill();
	public String getProfession();
	public int upgradeHP();
	public int upgradeMP();
	public int upgradeSTR();
	public int upgradeDEX();
	public int upgradeINT();
}


