import java.util.*;

class Beginner{
	private int STR=1,DEX=1,INT=1,HP=50,MP=50,LV=1;
	void use_skill(Profession p) {
		System.out.println(p.skill());
	}
	void showAP(Profession p) {
		System.out.println("----"+p.getProfession()+" LV."+LV+"----");
		System.out.println("HP : "+HP);
		System.out.println("MP : "+MP);
		System.out.println("STR : "+STR);
		System.out.println("DEX : "+DEX);
		System.out.println("INT : "+INT);
	}
	void levelup(Profession p) {		
		LV++;
		System.out.println("Level Up! LV."+LV+" Congratulations !");
		HP+=p.upgradeHP();
		MP+=p.upgradeMP();
		STR+=p.upgradeSTR();
		DEX+=p.upgradeDEX();
		INT+=p.upgradeINT();
	}
}

public class Main{
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		
		System.out.println("Hello Beginner ! Please choose your Profession.");
		System.out.println("(1) Warrior");
		System.out.println("(2) Magician");
		System.out.println("(3) Archer");
		int choice=sc.nextInt();
		
		Beginner person = new Beginner();
		Profession profession=null;
		
		switch(choice) {
			case 1:
				profession = new Warrior();
				break;
			case 2:
				profession = new Magician();
				break;
			case 3:
				profession = new Archer();
				break;
			default:
				break;
		}
		
		while(choice>=1&&choice<=3){
			System.out.println("\n\n\nWhat do you want to do?");
			System.out.println("(1) Level Up!");
			System.out.println("(2) Use skill.");
			System.out.println("(3) Show my ability point.");
			System.out.println("(4) Exit.");
			int select=sc.nextInt();
			
			if(select==4)
				break;
			
			switch(select) {
				case 1:
					person.levelup(profession);
					break;
				case 2:
					person.use_skill(profession);
					break;
				case 3:
					person.showAP(profession);
					break;
				default:
					break;
			}
			
			
		}
	}
	
}

